import sqlite3
import os
import logging

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Database configuration
DATABASE_PATH = "resumes.db"

def init_database():
    
    try:
        # Remove existing database if it exists (for fresh start)
        if os.path.exists(DATABASE_PATH):
            os.remove(DATABASE_PATH)
            logger.info("Removed existing database")
        
        # Create new database connection
        conn = sqlite3.connect(DATABASE_PATH)
        cursor = conn.cursor()
        
        # Create resumes table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS resumes (
                id TEXT PRIMARY KEY,
                filename TEXT NOT NULL,
                text TEXT NOT NULL,
                skills TEXT,
                embedding TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        # Create index on filename for faster searches
        cursor.execute('''
            CREATE INDEX IF NOT EXISTS idx_filename ON resumes(filename)
        ''')
        
        # Create index on created_at for sorting
        cursor.execute('''
            CREATE INDEX IF NOT EXISTS idx_created_at ON resumes(created_at)
        ''')
        
        conn.commit()
        conn.close()
        
        logger.info("Database initialized successfully")
        print("✅ Database initialized successfully!")
        print(f"📁 Database file created at: {os.path.abspath(DATABASE_PATH)}")
        
    except Exception as e:
        logger.error(f"Error initializing database: {str(e)}")
        print(f"❌ Error initializing database: {str(e)}")
        raise

def test_database():
    """Test database connection and basic operations"""
    try:
        conn = sqlite3.connect(DATABASE_PATH)
        cursor = conn.cursor()
        
        # Test table exists
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='resumes'")
        table_exists = cursor.fetchone()
        
        if table_exists:
            print("✅ Table 'resumes' exists")
        else:
            print("❌ Table 'resumes' does not exist")
        
        # Test table structure
        cursor.execute("PRAGMA table_info(resumes)")
        columns = cursor.fetchall()
        
        print("📋 Table structure:")
        for column in columns:
            print(f"   - {column[1]} ({column[2]})")
        
        conn.close()
        print("✅ Database test completed successfully!")
        
    except Exception as e:
        logger.error(f"Error testing database: {str(e)}")
        print(f"❌ Error testing database: {str(e)}")
        raise

if __name__ == "__main__":
    print("🚀 Initializing ResumeRAG Database...")
    print("=" * 50)
    
    init_database()
    test_database()
    
    print("=" * 50)
    print("🎉 Database initialization completed!")
    print("\nNext steps:")
    print("1. Set your OpenAI API key: export OPENAI_API_KEY='your-api-key'")
    print("2. Install requirements: pip install -r requirements.txt")
    print("3. Start the backend: uvicorn main:app --reload")

