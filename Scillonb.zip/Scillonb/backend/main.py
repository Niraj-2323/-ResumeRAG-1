from fastapi import FastAPI, File, UploadFile, HTTPException, Form
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
import sqlite3
import os
import json
import logging
from typing import List, Dict, Any
import PyPDF2
import docx
import openai
from sklearn.metrics.pairwise import cosine_similarity
import numpy as np
import re
from datetime import datetime
import uuid

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Initialize FastAPI app
app = FastAPI(title="ResumeRAG API", version="1.0.0")

# CORS middleware for frontend communication
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000", "http://127.0.0.1:3000"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# OpenAI configuration
openai.api_key = os.getenv("OPENAI_API_KEY")

# Database configuration
DATABASE_PATH = "resumes.db"

def init_database():
    """Initialize SQLite database with resumes table"""
    conn = sqlite3.connect(DATABASE_PATH)
    cursor = conn.cursor()
    
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS resumes (
            id TEXT PRIMARY KEY,
            filename TEXT NOT NULL,
            text TEXT NOT NULL,
            skills TEXT,
            embedding TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    conn.commit()
    conn.close()
    logger.info("Database initialized successfully")

def extract_text_from_pdf(file_content: bytes) -> str:
    """Extract text from PDF file"""
    try:
        pdf_reader = PyPDF2.PdfReader(io.BytesIO(file_content))
        text = ""
        for page in pdf_reader.pages:
            text += page.extract_text() + "\n"
        return text.strip()
    except Exception as e:
        logger.error(f"Error extracting text from PDF: {str(e)}")
        raise HTTPException(status_code=400, detail="Failed to extract text from PDF")

def extract_text_from_docx(file_content: bytes) -> str:
    """Extract text from DOCX file"""
    try:
        doc = docx.Document(io.BytesIO(file_content))
        text = ""
        for paragraph in doc.paragraphs:
            text += paragraph.text + "\n"
        return text.strip()
    except Exception as e:
        logger.error(f"Error extracting text from DOCX: {str(e)}")
        raise HTTPException(status_code=400, detail="Failed to extract text from DOCX")

def extract_skills_from_text(text: str) -> List[str]:
    """Extract skills from resume text using regex patterns"""
    # Common technical skills patterns
    skill_patterns = [
        r'\b(?:Python|Java|JavaScript|React|Node\.?js|Angular|Vue|SQL|MongoDB|PostgreSQL|MySQL|AWS|Azure|Docker|Kubernetes|Git|Linux|Windows|MacOS)\b',
        r'\b(?:HTML|CSS|Bootstrap|jQuery|Express|Django|Flask|FastAPI|Spring|Hibernate|Maven|Gradle)\b',
        r'\b(?:Machine Learning|AI|Data Science|Analytics|Statistics|Pandas|NumPy|Scikit-learn|TensorFlow|PyTorch)\b',
        r'\b(?:Project Management|Agile|Scrum|DevOps|CI/CD|Jenkins|GitLab|GitHub)\b',
        r'\b(?:Communication|Leadership|Teamwork|Problem Solving|Analytical|Creative|Detail-oriented)\b'
    ]
    
    skills = set()
    for pattern in skill_patterns:
        matches = re.findall(pattern, text, re.IGNORECASE)
        skills.update(matches)
    
    return list(skills)

def generate_embedding(text: str) -> List[float]:
    """Generate embedding using OpenAI API"""
    try:
        response = openai.embeddings.create(
            model="text-embedding-3-small",
            input=text
        )
        return response.data[0].embedding
    except Exception as e:
        logger.error(f"Error generating embedding: {str(e)}")
        raise HTTPException(status_code=500, detail="Failed to generate embedding")

def calculate_cosine_similarity(embedding1: List[float], embedding2: List[float]) -> float:
    """Calculate cosine similarity between two embeddings"""
    try:
        # Convert to numpy arrays and reshape for sklearn
        vec1 = np.array(embedding1).reshape(1, -1)
        vec2 = np.array(embedding2).reshape(1, -1)
        
        similarity = cosine_similarity(vec1, vec2)[0][0]
        return float(similarity)
    except Exception as e:
        logger.error(f"Error calculating similarity: {str(e)}")
        return 0.0

@app.on_event("startup")
async def startup_event():
    """Initialize database on startup"""
    init_database()

@app.get("/")
async def root():
    """Health check endpoint"""
    return {"message": "ResumeRAG API is running", "status": "healthy"}

@app.post("/upload_resume")
async def upload_resume(file: UploadFile = File(...)):
    """Upload and process a resume file"""
    try:
        # Validate file type
        if not file.filename.lower().endswith(('.pdf', '.docx')):
            raise HTTPException(status_code=400, detail="Only PDF and DOCX files are allowed")
        
        # Read file content
        file_content = await file.read()
        
        # Extract text based on file type
        if file.filename.lower().endswith('.pdf'):
            text = extract_text_from_pdf(file_content)
        else:
            text = extract_text_from_docx(file_content)
        
        if not text.strip():
            raise HTTPException(status_code=400, detail="No text could be extracted from the file")
        
        # Extract skills
        skills = extract_skills_from_text(text)
        
        # Generate embedding
        embedding = generate_embedding(text)
        
        # Generate unique ID
        resume_id = str(uuid.uuid4())
        
        # Store in database
        conn = sqlite3.connect(DATABASE_PATH)
        cursor = conn.cursor()
        
        cursor.execute('''
            INSERT INTO resumes (id, filename, text, skills, embedding)
            VALUES (?, ?, ?, ?, ?)
        ''', (resume_id, file.filename, text, json.dumps(skills), json.dumps(embedding)))
        
        conn.commit()
        conn.close()
        
        logger.info(f"Successfully uploaded resume: {file.filename}")
        
        return JSONResponse(
            status_code=200,
            content={
                "message": "Resume uploaded successfully",
                "resume_id": resume_id,
                "filename": file.filename,
                "skills_found": skills,
                "text_length": len(text)
            }
        )
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error uploading resume: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")

@app.post("/upload_resumes_bulk")
async def upload_resumes_bulk(files: List[UploadFile] = File(...)):
    """Upload multiple resume files"""
    results = []
    errors = []
    
    for file in files:
        try:
            result = await upload_resume(file)
            results.append(result.body.decode())
        except Exception as e:
            errors.append({"filename": file.filename, "error": str(e)})
    
    return JSONResponse(
        status_code=200,
        content={
            "message": f"Bulk upload completed. {len(results)} successful, {len(errors)} failed.",
            "successful_uploads": results,
            "errors": errors
        }
    )

@app.post("/match_resumes")
async def match_resumes(job_description: str = Form(...)):
    """Find matching resumes for a job description"""
    try:
        if not job_description.strip():
            raise HTTPException(status_code=400, detail="Job description cannot be empty")
        
        # Generate embedding for job description
        job_embedding = generate_embedding(job_description)
        
        # Get all resumes from database
        conn = sqlite3.connect(DATABASE_PATH)
        cursor = conn.cursor()
        
        cursor.execute('SELECT id, filename, text, skills, embedding FROM resumes')
        resumes = cursor.fetchall()
        conn.close()
        
        if not resumes:
            return JSONResponse(
                status_code=200,
                content={
                    "message": "No resumes found in database",
                    "matches": []
                }
            )
        
        # Calculate similarities
        matches = []
        for resume in resumes:
            resume_id, filename, text, skills_json, embedding_json = resume
            
            try:
                resume_embedding = json.loads(embedding_json)
                similarity = calculate_cosine_similarity(job_embedding, resume_embedding)
                
                # Calculate percentage
                similarity_percentage = round(similarity * 100, 2)
                
                # Parse skills
                skills = json.loads(skills_json) if skills_json else []
                
                # Find matching keywords in job description
                job_keywords = re.findall(r'\b\w+\b', job_description.lower())
                matched_skills = [skill for skill in skills if skill.lower() in job_keywords]
                
                matches.append({
                    "resume_id": resume_id,
                    "filename": filename,
                    "similarity_score": similarity_percentage,
                    "matched_skills": matched_skills,
                    "all_skills": skills,
                    "text_preview": text[:200] + "..." if len(text) > 200 else text
                })
                
            except Exception as e:
                logger.error(f"Error processing resume {filename}: {str(e)}")
                continue
        
        # Sort by similarity score (descending)
        matches.sort(key=lambda x: x["similarity_score"], reverse=True)
        
        logger.info(f"Found {len(matches)} matching resumes for job description")
        
        return JSONResponse(
            status_code=200,
            content={
                "message": f"Found {len(matches)} matching resumes",
                "matches": matches,
                "job_description": job_description
            }
        )
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error matching resumes: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")

@app.get("/resumes")
async def get_all_resumes():
    """Get all uploaded resumes"""
    try:
        conn = sqlite3.connect(DATABASE_PATH)
        cursor = conn.cursor()
        
        cursor.execute('SELECT id, filename, created_at FROM resumes ORDER BY created_at DESC')
        resumes = cursor.fetchall()
        conn.close()
        
        return JSONResponse(
            status_code=200,
            content={
                "resumes": [
                    {
                        "id": resume[0],
                        "filename": resume[1],
                        "created_at": resume[2]
                    }
                    for resume in resumes
                ]
            }
        )
        
    except Exception as e:
        logger.error(f"Error fetching resumes: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")

@app.delete("/resumes/{resume_id}")
async def delete_resume(resume_id: str):
    """Delete a resume by ID"""
    try:
        conn = sqlite3.connect(DATABASE_PATH)
        cursor = conn.cursor()
        
        cursor.execute('DELETE FROM resumes WHERE id = ?', (resume_id,))
        
        if cursor.rowcount == 0:
            conn.close()
            raise HTTPException(status_code=404, detail="Resume not found")
        
        conn.commit()
        conn.close()
        
        return JSONResponse(
            status_code=200,
            content={"message": "Resume deleted successfully"}
        )
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error deleting resume: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)

