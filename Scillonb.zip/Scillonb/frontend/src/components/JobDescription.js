import React, { useState } from 'react';
import axios from 'axios';
import './JobDescription.css';

const JobDescription = ({ onResults }) => {
  const [jobDescription, setJobDescription] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');

  const API_BASE_URL = 'http://localhost:8000';

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!jobDescription.trim()) {
      setError('Please enter a job description');
      return;
    }

    setIsLoading(true);
    setError('');

    try {
      const formData = new FormData();
      formData.append('job_description', jobDescription);

      const response = await axios.post(`${API_BASE_URL}/match_resumes`, formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      });

      if (onResults) {
        onResults(response.data);
      }

    } catch (error) {
      setError(error.response?.data?.detail || 'Failed to find matching resumes');
    } finally {
      setIsLoading(false);
    }
  };

  const handleClear = () => {
    setJobDescription('');
    setError('');
  };

  return (
    <div className="job-description-container">
      <div className="job-header">
        <h2>🔍 Find Matching Resumes</h2>
        <p>Enter a job description to find the best matching resumes using AI</p>
      </div>

      <form onSubmit={handleSubmit} className="job-form">
        <div className="form-group">
          <label htmlFor="job-description" className="form-label">
            Job Description *
          </label>
          <textarea
            id="job-description"
            value={jobDescription}
            onChange={(e) => setJobDescription(e.target.value)}
            placeholder="Enter the job description, requirements, and skills needed for this position..."
            className="job-textarea"
            rows="8"
            disabled={isLoading}
            required
          />
          <div className="character-count">
            {jobDescription.length} characters
          </div>
        </div>

        {error && (
          <div className="error-message">
            ❌ {error}
          </div>
        )}

        <div className="form-actions">
          <button
            type="button"
            className="clear-btn"
            onClick={handleClear}
            disabled={isLoading || !jobDescription.trim()}
          >
            🗑️ Clear
          </button>
          
          <button
            type="submit"
            className="search-btn"
            disabled={isLoading || !jobDescription.trim()}
          >
            {isLoading ? (
              <>
                <span className="spinner"></span>
                Finding Matches...
              </>
            ) : (
              <>
                🔍 Find Matching Resumes
              </>
            )}
          </button>
        </div>
      </form>

      <div className="job-tips">
        <h4>💡 Tips for better matching:</h4>
        <ul>
          <li>Include specific technical skills and requirements</li>
          <li>Mention years of experience needed</li>
          <li>List programming languages, frameworks, or tools</li>
          <li>Include soft skills and qualifications</li>
          <li>Be specific about job responsibilities</li>
        </ul>
      </div>

      <div className="example-description">
        <h4>📝 Example Job Description:</h4>
        <div className="example-content">
          <strong>Senior Full Stack Developer</strong>
          <p>
            We are looking for a Senior Full Stack Developer with 5+ years of experience 
            in React, Node.js, and Python. The ideal candidate should have experience 
            with AWS, Docker, and PostgreSQL. Strong communication skills and experience 
            with Agile methodologies are required. Knowledge of machine learning and 
            data science is a plus.
          </p>
        </div>
      </div>
    </div>
  );
};

export default JobDescription;

