import React, { useState } from 'react';
import axios from 'axios';
import './Results.css';

const Results = ({ results, jobDescription }) => {
  const [expandedResume, setExpandedResume] = useState(null);
  const [isDeleting, setIsDeleting] = useState(null);

  const API_BASE_URL = 'http://localhost:8000';

  const handleDeleteResume = async (resumeId, filename) => {
    if (!window.confirm(`Are you sure you want to delete "${filename}"?`)) {
      return;
    }

    setIsDeleting(resumeId);

    try {
      await axios.delete(`${API_BASE_URL}/resumes/${resumeId}`);
      
      // Remove the deleted resume from results
      const updatedResults = {
        ...results,
        matches: results.matches.filter(match => match.resume_id !== resumeId)
      };
      
      // Update the parent component
      if (window.updateResults) {
        window.updateResults(updatedResults);
      }

    } catch (error) {
      alert('Failed to delete resume: ' + (error.response?.data?.detail || 'Unknown error'));
    } finally {
      setIsDeleting(null);
    }
  };

  const getScoreColor = (score) => {
    if (score >= 80) return 'excellent';
    if (score >= 60) return 'good';
    if (score >= 40) return 'fair';
    return 'poor';
  };

  const getScoreLabel = (score) => {
    if (score >= 80) return 'Excellent Match';
    if (score >= 60) return 'Good Match';
    if (score >= 40) return 'Fair Match';
    return 'Poor Match';
  };

  const toggleExpanded = (resumeId) => {
    setExpandedResume(expandedResume === resumeId ? null : resumeId);
  };

  if (!results || !results.matches || results.matches.length === 0) {
    return (
      <div className="results-container">
        <div className="no-results">
          <div className="no-results-icon">🔍</div>
          <h3>No Matching Resumes Found</h3>
          <p>No resumes match the current job description criteria.</p>
          <div className="suggestions">
            <h4>Suggestions:</h4>
            <ul>
              <li>Try uploading more resumes</li>
              <li>Modify the job description</li>
              <li>Use broader skill terms</li>
            </ul>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="results-container">
      <div className="results-header">
        <h2>🎯 Matching Results</h2>
        <div className="results-summary">
          <span className="total-matches">
            Found {results.matches.length} matching resume{results.matches.length !== 1 ? 's' : ''}
          </span>
          <span className="job-description-preview">
            Job: "{jobDescription?.substring(0, 50)}..."
          </span>
        </div>
      </div>

      <div className="results-list">
        {results.matches.map((match, index) => (
          <div key={match.resume_id} className="result-card">
            <div className="result-header">
              <div className="result-rank">
                <span className="rank-number">#{index + 1}</span>
                <div className={`score-badge ${getScoreColor(match.similarity_score)}`}>
                  <span className="score-percentage">{match.similarity_score}%</span>
                  <span className="score-label">{getScoreLabel(match.similarity_score)}</span>
                </div>
              </div>
              
              <div className="result-info">
                <h3 className="resume-filename">{match.filename}</h3>
                <div className="resume-preview">
                  {match.text_preview}
                </div>
              </div>

              <div className="result-actions">
                <button
                  className="expand-btn"
                  onClick={() => toggleExpanded(match.resume_id)}
                >
                  {expandedResume === match.resume_id ? '📖 Less' : '📖 More'}
                </button>
                
                <button
                  className="delete-btn"
                  onClick={() => handleDeleteResume(match.resume_id, match.filename)}
                  disabled={isDeleting === match.resume_id}
                >
                  {isDeleting === match.resume_id ? (
                    <span className="spinner"></span>
                  ) : (
                    '🗑️'
                  )}
                </button>
              </div>
            </div>

            {expandedResume === match.resume_id && (
              <div className="result-details">
                <div className="skills-section">
                  <h4>🎯 Matched Skills</h4>
                  {match.matched_skills && match.matched_skills.length > 0 ? (
                    <div className="matched-skills">
                      {match.matched_skills.map((skill, skillIndex) => (
                        <span key={skillIndex} className="matched-skill">
                          ✅ {skill}
                        </span>
                      ))}
                    </div>
                  ) : (
                    <p className="no-matched-skills">No specific skills matched</p>
                  )}
                </div>

                <div className="all-skills-section">
                  <h4>📋 All Skills Found</h4>
                  {match.all_skills && match.all_skills.length > 0 ? (
                    <div className="all-skills">
                      {match.all_skills.map((skill, skillIndex) => (
                        <span key={skillIndex} className="all-skill">
                          {skill}
                        </span>
                      ))}
                    </div>
                  ) : (
                    <p className="no-skills">No skills extracted</p>
                  )}
                </div>

                <div className="similarity-breakdown">
                  <h4>📊 Match Analysis</h4>
                  <div className="analysis-grid">
                    <div className="analysis-item">
                      <span className="analysis-label">Similarity Score:</span>
                      <span className="analysis-value">{match.similarity_score}%</span>
                    </div>
                    <div className="analysis-item">
                      <span className="analysis-label">Skills Matched:</span>
                      <span className="analysis-value">{match.matched_skills?.length || 0}</span>
                    </div>
                    <div className="analysis-item">
                      <span className="analysis-label">Total Skills:</span>
                      <span className="analysis-value">{match.all_skills?.length || 0}</span>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        ))}
      </div>

      <div className="results-footer">
        <div className="score-legend">
          <h4>📈 Score Legend:</h4>
          <div className="legend-items">
            <div className="legend-item excellent">
              <span className="legend-color"></span>
              <span>80-100%: Excellent Match</span>
            </div>
            <div className="legend-item good">
              <span className="legend-color"></span>
              <span>60-79%: Good Match</span>
            </div>
            <div className="legend-item fair">
              <span className="legend-color"></span>
              <span>40-59%: Fair Match</span>
            </div>
            <div className="legend-item poor">
              <span className="legend-color"></span>
              <span>0-39%: Poor Match</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Results;

