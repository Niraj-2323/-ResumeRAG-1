import React, { useState } from 'react';
import axios from 'axios';
import './UploadResume.css';

const UploadResume = ({ onUploadSuccess }) => {
  const [files, setFiles] = useState([]);
  const [uploading, setUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [message, setMessage] = useState('');
  const [messageType, setMessageType] = useState('');

  const API_BASE_URL = 'http://localhost:8000';

  const handleFileChange = (e) => {
    const selectedFiles = Array.from(e.target.files);
    const validFiles = selectedFiles.filter(file => 
      file.type === 'application/pdf' || 
      file.type === 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
    );

    if (validFiles.length !== selectedFiles.length) {
      setMessage('Only PDF and DOCX files are allowed');
      setMessageType('error');
    } else {
      setFiles(validFiles);
      setMessage('');
      setMessageType('');
    }
  };

  const uploadSingleFile = async (file) => {
    const formData = new FormData();
    formData.append('file', file);

    try {
      const response = await axios.post(`${API_BASE_URL}/upload_resume`, formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      });
      return response.data;
    } catch (error) {
      throw new Error(error.response?.data?.detail || 'Upload failed');
    }
  };

  const uploadBulkFiles = async () => {
    const formData = new FormData();
    files.forEach(file => {
      formData.append('files', file);
    });

    try {
      const response = await axios.post(`${API_BASE_URL}/upload_resumes_bulk`, formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      });
      return response.data;
    } catch (error) {
      throw new Error(error.response?.data?.detail || 'Bulk upload failed');
    }
  };

  const handleUpload = async () => {
    if (files.length === 0) {
      setMessage('Please select at least one file');
      setMessageType('error');
      return;
    }

    setUploading(true);
    setUploadProgress(0);
    setMessage('');

    try {
      let result;
      
      if (files.length === 1) {
        // Single file upload
        result = await uploadSingleFile(files[0]);
        setUploadProgress(100);
      } else {
        // Bulk upload
        result = await uploadBulkFiles();
        setUploadProgress(100);
      }

      setMessage(`Successfully uploaded ${files.length} resume(s)`);
      setMessageType('success');
      
      // Reset form
      setFiles([]);
      document.getElementById('file-input').value = '';
      
      // Notify parent component
      if (onUploadSuccess) {
        onUploadSuccess(result);
      }

    } catch (error) {
      setMessage(`Upload failed: ${error.message}`);
      setMessageType('error');
    } finally {
      setUploading(false);
      setTimeout(() => {
        setMessage('');
        setMessageType('');
        setUploadProgress(0);
      }, 3000);
    }
  };

  const removeFile = (index) => {
    const newFiles = files.filter((_, i) => i !== index);
    setFiles(newFiles);
  };

  return (
    <div className="upload-resume-container">
      <div className="upload-header">
        <h2>📄 Upload Resumes</h2>
        <p>Upload PDF or DOCX resume files for AI-powered matching</p>
      </div>

      <div className="upload-area">
        <div className="file-input-container">
          <input
            id="file-input"
            type="file"
            multiple
            accept=".pdf,.docx"
            onChange={handleFileChange}
            className="file-input"
            disabled={uploading}
          />
          <label htmlFor="file-input" className="file-input-label">
            <div className="upload-icon">📁</div>
            <div className="upload-text">
              <strong>Choose Files</strong>
              <span>or drag and drop here</span>
            </div>
            <div className="file-types">PDF, DOCX files only</div>
          </label>
        </div>

        {files.length > 0 && (
          <div className="selected-files">
            <h4>Selected Files ({files.length})</h4>
            <div className="file-list">
              {files.map((file, index) => (
                <div key={index} className="file-item">
                  <div className="file-info">
                    <span className="file-icon">
                      {file.type === 'application/pdf' ? '📄' : '📝'}
                    </span>
                    <span className="file-name">{file.name}</span>
                    <span className="file-size">
                      ({(file.size / 1024 / 1024).toFixed(2)} MB)
                    </span>
                  </div>
                  <button
                    type="button"
                    className="remove-file-btn"
                    onClick={() => removeFile(index)}
                    disabled={uploading}
                  >
                    ✕
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}

        {uploading && (
          <div className="upload-progress">
            <div className="progress-bar">
              <div 
                className="progress-fill" 
                style={{ width: `${uploadProgress}%` }}
              ></div>
            </div>
            <div className="progress-text">
              Uploading... {uploadProgress}%
            </div>
          </div>
        )}

        {message && (
          <div className={`message ${messageType}`}>
            {messageType === 'success' ? '✅' : '❌'} {message}
          </div>
        )}

        <button
          className="upload-btn"
          onClick={handleUpload}
          disabled={files.length === 0 || uploading}
        >
          {uploading ? (
            <>
              <span className="spinner"></span>
              Uploading...
            </>
          ) : (
            <>
              🚀 Upload {files.length} Resume{files.length !== 1 ? 's' : ''}
            </>
          )}
        </button>
      </div>

      <div className="upload-tips">
        <h4>💡 Tips for best results:</h4>
        <ul>
          <li>Ensure resumes contain clear skill descriptions</li>
          <li>Use standard file formats (PDF or DOCX)</li>
          <li>Keep file sizes under 10MB</li>
          <li>Upload multiple resumes for better matching</li>
        </ul>
      </div>
    </div>
  );
};

export default UploadResume;

